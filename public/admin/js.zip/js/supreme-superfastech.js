(function ($) {
  'use strict';
  AOS.init();


// password eye

  $("#show_hide_password a").on('click', function(event) {
    event.preventDefault();
    if ($('#show_hide_password input').attr("type") == "text") {
        $('#show_hide_password input').attr('type', 'password');
        $('#show_hide_password i').addClass("fa-eye-slash");
        $('#show_hide_password i').removeClass("fa-eye");
    } else if ($('#show_hide_password input').attr("type") == "password") {
        $('#show_hide_password input').attr('type', 'text');
        $('#show_hide_password i').removeClass("fa-eye-slash");
        $('#show_hide_password i').addClass("fa-eye");
    }
});


// icon rotate

$(".product-menu .nav-item").click(function(){

  if ($(this).hasClass("arrow-rotate")) {
    $(".product-menu .nav-item").removeClass("arrow-rotate");
  } 
  else {
    $(".product-menu .nav-item").removeClass("arrow-rotate");
    $(this).addClass("arrow-rotate");
  }
});


// menu show moere or hide

$(".show-btn a").click(function(){
  $(".show-btn").addClass("hide");
  $(".hide-grid").removeClass("hide");

});

$(".hide-btn").click(function(){
  $(".hide-grid").addClass("hide");
  $(".show-btn").removeClass("hide");
});


// side bar

document.addEventListener("DOMContentLoaded", function() {
  document.querySelectorAll('.sidebar .nav-link').forEach(function(element) {

      element.addEventListener('click', function(e) {

          let nextEl = element.nextElementSibling;
          let parentEl = element.parentElement;

          if (nextEl) {
              e.preventDefault();
              let mycollapse = new bootstrap.Collapse(nextEl);

              if (nextEl.classList.contains('show')) {
                  mycollapse.hide();
              } else {
                  mycollapse.show();
                  // find other submenus with class=show
                  var opened_submenu = parentEl.parentElement.querySelector('.submenu.show');
                  // if it exists, then close all of them
                  if (opened_submenu) {
                      new bootstrap.Collapse(opened_submenu);
                  }
              }
          }
      }); // addEventListener
  }) // forEach
});


// pop-up-product

      /*-- popusps --*/
      
      $(document).ready(function(){
        $('.btnn').click(function(event) {
        $('.quick-popup, .overlay').addClass('is-active');
        return false;
        });
        $('.popup__close, .overlay').click(function(event) {
        $('.quick-popup, .overlay').removeClass('is-active');
        return false;
        });
        });



  //Avoid pinch zoom on iOS
  document.addEventListener('touchmove', function (event) {
    if (event.scale !== 1) {
      event.preventDefault();
    }
  }, false);
})(jQuery)